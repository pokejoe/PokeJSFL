Unzip this archive in the following directory
このアーカイブファイルを以下のフォールだーにご解凍ください。

C:\Users\user.name\AppData\Local\Adobe\Flash CS6\ja_JP\Configuration\WindowSWF
            ^                               ^      ^
		 Windows login           Flash version     Flash install language
         Windowsユーザー名　　　　　　　Flashバージョン　　　　　Flashのインストールされた言語